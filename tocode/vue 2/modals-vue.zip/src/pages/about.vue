<template>
  <div class="md-body">
    <h1>В этом приложении:</h1>
    <ul>
      <li>Vue-Router в связке Vue.js 3</li>
      <li>Динамические маршруты</li>
      <li>Установка своих тем поврех своего шаблона vue cli</li>
      <li>
        Понимание того, как работают темы для фреймворков по типу Material UI
      </li>
      <li>Критерии выбора библиотеки</li>
      <li>
        Разбор библиотек и взгляд "изнутри". Полное понимание того, как пишутся
        библиотеки
      </li>
      <li>Слайдер с персонажами</li>
    </ul>
    <p>
      Сделано на курсе
      <a style="color: #ffffff;" href="https://tocode.ru/courses/vuejs-3-s-nulya-do-rezultata/"
        >Vue.js 3 С нуля до результата</a
      >
    </p>
  </div>
</template>
