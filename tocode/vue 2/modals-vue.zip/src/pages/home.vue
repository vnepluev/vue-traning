<template>
  <p>Home page</p>
</template>
