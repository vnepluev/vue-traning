<template>
  <h1 class="title">404 not found page</h1>
</template>
