// https://cli.vuejs.org/ru/config/#vue-config-js
module.exports = {
  publicPath: "",
  productionSourceMap: false,
  assetsDir: "assets",
};
